"""Autenticação: bcrypt (senha e CPF)."""
import time
from functools import wraps

import bcrypt
from flask import jsonify, redirect, session

from db import ErroNegocio, query

EXPIRACAO_SEGUNDOS = 30 * 60  # 30 minutos


def gerar_hash(texto):
    return bcrypt.hashpw(texto.encode("utf-8"), bcrypt.gensalt(rounds=10)).decode("utf-8")


def conferir(texto, hash_salvo):
    try:
        return bcrypt.checkpw(texto.encode("utf-8"), hash_salvo.encode("utf-8"))
    except (AttributeError, ValueError):
        return False


def autenticar(login, senha):
    login, senha = (login or "").strip(), senha or ""
    if not login or not senha:
        raise ErroNegocio("Informe usuário.", 400)
    usuarios = query("SELECT id, nome, senha_hash FROM Usuarios WHERE login = %s", (login,))
    if not usuarios or not conferir(senha, usuarios[0].get("senha_hash")):
        raise ErroNegocio("Usuário ou senha inválidos.", 401)
    return usuarios[0]


def iniciar_sessao(usuario):
    session.clear()
    session.permanent = True
    session.update(usuario_id=usuario["id"], nome=usuario["nome"], login_em=time.time())


def logado():
    if "usuario_id" not in session:
        return False
    if time.time() - session.get("login_em", 0) > EXPIRACAO_SEGUNDOS:
        session.clear()
        return False
    return True


def api_protegida(f):
    @wraps(f)
    def interno(*args, **kwargs):
        if not logado():
            return jsonify(erro="Sessão expirada. Faça o login novamente."), 401
        return f(*args, **kwargs)
    return interno


def pagina_protegida(f):
    @wraps(f)
    def interno(*args, **kwargs):
        if not logado():
            return redirect("/login")
        return f(*args, **kwargs)
    return interno
